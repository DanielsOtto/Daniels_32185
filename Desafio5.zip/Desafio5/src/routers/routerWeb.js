const express = require('express');
const { controllerGet, controllerPost, controllerForm } = require('../controllers/controller.js')


const routerWeb = express.Router();
routerWeb.get('/', controllerForm); // anda
routerWeb.get('/', controllerGet); // CARGA de formulario
routerWeb.post('/', controllerPost); // OBTENER formulario

exports.routerWeb = routerWeb;