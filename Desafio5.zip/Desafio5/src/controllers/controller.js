const element = require('../Container');
// const { randomUUID } = require('crypto');

async function form(req, res) {
  try {
    res.render('form');
  } catch (error) {
    throw new Error('Error al cargar el formulario');
  }
};

async function get(req, res) {
  try {
    const array = await element.getAll();
    res.render('historial', { array, hayProductos: array.length > 0 });
  } catch (error) {
    throw new Error(error);
  }
}

// routerApi.get('/productos', (req, res) => {
//   ContainerProd.getProductos().then(data => res.render('lista', { hayProductos: data.length > 0, data }));
// });
async function post({ body }, res) {
  try {
    const object = body;
    // object.id = randomUUID();
    await element.save(object);
    res.status(201);
    res.redirect('/')
  } catch (error) {
    throw new Error('Se ha producido un error en el controlador POST');
  }
}

exports.controllerGet = get;
exports.controllerPost = post;
exports.controllerForm = form;